package com.garage;

public interface InputForm {
    public void enterNeededInfo();
}
