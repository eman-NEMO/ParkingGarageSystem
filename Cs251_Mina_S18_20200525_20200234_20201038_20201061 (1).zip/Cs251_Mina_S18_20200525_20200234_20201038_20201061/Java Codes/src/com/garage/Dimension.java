package com.garage;

public class Dimension {
    private int width, depth;
    public Dimension(int w, int d)
    {
        width = w;
        depth = d;
    }

    public int getDepth() {
        return depth;
    }

    public int getWidth() {
        return width;
    }
}
