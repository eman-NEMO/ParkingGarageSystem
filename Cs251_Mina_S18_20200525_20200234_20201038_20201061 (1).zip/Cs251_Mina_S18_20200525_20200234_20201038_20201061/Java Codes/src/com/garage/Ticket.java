package com.garage;

public class Ticket {
    public void print(int slotID)
    {
        System.out.println("---Ticket---");
        System.out.println("Your Slot ID: " + slotID);
    }
}
