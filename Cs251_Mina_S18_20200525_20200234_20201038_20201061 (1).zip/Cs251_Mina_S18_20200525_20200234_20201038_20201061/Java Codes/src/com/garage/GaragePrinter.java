package com.garage;

public interface GaragePrinter {
    void print();
}
