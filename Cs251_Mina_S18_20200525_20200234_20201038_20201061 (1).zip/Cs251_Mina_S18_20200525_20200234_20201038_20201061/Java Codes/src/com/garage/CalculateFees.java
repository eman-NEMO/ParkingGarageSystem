package com.garage;

public interface CalculateFees {
    void calculateFess(GarageParking j);
    long getSum();
    long getRes();
}
