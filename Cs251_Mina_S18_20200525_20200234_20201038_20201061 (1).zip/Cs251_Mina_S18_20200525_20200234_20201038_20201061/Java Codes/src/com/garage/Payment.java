package com.garage;

public interface Payment {
    void payment();
}
